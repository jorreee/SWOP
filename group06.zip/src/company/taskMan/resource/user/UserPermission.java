package company.taskMan.resource.user;

public enum UserPermission {
	
	SHOW_OVERVIEW,
	ADVANCE_TIME,
	CREATE_PROJECT,
	CREATE_TASK,
	PLAN_TASK,
	UPDATE_TASK,
	SIMULATE,
	DELEGATE_TASK;

}
