package initialization;

public class IntPair {
	public int first;
	public int second;
}
