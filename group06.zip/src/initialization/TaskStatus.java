package initialization;

public enum TaskStatus { EXECUTING, FINISHED, FAILED, DELEGATED }
