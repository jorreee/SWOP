package taskMan;

public enum ProjectStatus {
	
	ONGOING, FINISHED
	
}
