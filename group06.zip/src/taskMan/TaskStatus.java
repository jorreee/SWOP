package taskMan;

public enum TaskStatus {
	AVAILABLE, UNAVAILABLE, FAILED, FINISHED
}
